/**
 * visualMap component entry
 */
define(function (require) {

    require('./visualMapContinuous');
    require('./visualMapPiecewise');

});