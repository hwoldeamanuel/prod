document.write('<script src="core/utHelper.js"><\/script>');

// Specs ...
document.write('<script src="spec/util/graphic.js"><\/script>');
document.write('<script src="spec/util/model.js"><\/script>');
document.write('<script src="spec/util/number.js"><\/script>');
document.write('<script src="spec/model/Component.js"><\/script>');
document.write('<script src="spec/model/Global.js"><\/script>');
document.write('<script src="spec/model/timelineOptions.js"><\/script>');

document.write('<script src="spec/data/List.js"><\/script>');

document.write('<script src="spec/component/visualMap/setOption.js"><\/script>');
